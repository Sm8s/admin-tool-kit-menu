#!/bin/bash

echo "Systeminformationen"
echo "-------------------"
echo "Benutzer: $(whoami)"
echo "Hostname: $(hostname)"
echo "Datum: $(date)"
echo "Verzeichnis: $(pwd)"
uname -a 2>/dev/null || echo "uname nicht verfügbar"