#!/bin/bash

SOURCE_DIR="${1:-.}"
BACKUP_DIR="./backups"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
ARCHIVE_NAME="backup_$TIMESTAMP.tar.gz"

mkdir -p "$BACKUP_DIR"

tar -czf "$BACKUP_DIR/$ARCHIVE_NAME" "$SOURCE_DIR" 2>/dev/null

if [ $? -eq 0 ]; then
  echo "Backup erstellt: $BACKUP_DIR/$ARCHIVE_NAME"
else
  echo "Fehler beim Erstellen des Backups"
fi