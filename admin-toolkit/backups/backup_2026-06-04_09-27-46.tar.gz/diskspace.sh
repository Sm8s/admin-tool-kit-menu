#!/bin/bash

echo "Speicherübersicht:"
df -h