#!/bin/bash

echo "Aktueller Benutzer: $(whoami)"
echo "Aktuelles Verzeichnis: $(pwd)"