#!/bin/bash

set -u

WARNING_THRESHOLD=80
CRITICAL_THRESHOLD=90
SHOW_ALL=0
SORT_OUTPUT=0

show_help() {
  cat <<EOF
Usage:
  bash diskspace.sh [options]

Options:
  -w, --warning NUM     Warning threshold in %
  -c, --critical NUM    Critical threshold in %
  -a, --all             Alle Zeilen anzeigen
  -s, --sort            Nach Nutzung sortieren
  -h, --help            Hilfe
EOF
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      -w|--warning)
        WARNING_THRESHOLD="$2"
        shift 2
        ;;
      -c|--critical)
        CRITICAL_THRESHOLD="$2"
        shift 2
        ;;
      -a|--all)
        SHOW_ALL=1
        shift
        ;;
      -s|--sort)
        SORT_OUTPUT=1
        shift
        ;;
      -h|--help)
        show_help
        exit 0
        ;;
      *)
        echo "Unbekanntes Argument: $1"
        exit 1
        ;;
    esac
  done
}

print_header() {
  echo "=========================================="
  echo " Disk Usage Analyzer"
  echo "=========================================="
}

collect_df() {
  df -hP 2>/dev/null
}

analyze_line() {
  local fs="$1"
  local size="$2"
  local used="$3"
  local avail="$4"
  local usep="$5"
  local mount="$6"

  local percent="${usep%\%}"
  local state="OK"

  if [ "$percent" -ge "$CRITICAL_THRESHOLD" ]; then
    state="CRITICAL"
  elif [ "$percent" -ge "$WARNING_THRESHOLD" ]; then
    state="WARNING"
  fi

  if [ "$SHOW_ALL" -eq 1 ] || [ "$state" != "OK" ]; then
    printf "%-10s | %-20s | size=%-8s used=%-8s avail=%-8s use=%-5s | %s\n" \
      "$state" "$mount" "$size" "$used" "$avail" "$usep" "$fs"
  fi
}

main() {
  parse_args "$@"
  print_header

  local data
  data="$(collect_df)"

  if [ -z "$data" ]; then
    echo "df Ausgabe nicht verfügbar"
    exit 1
  fi

  echo "$data" | tail -n +2 > /tmp/diskspace_input.tmp

  if [ "$SORT_OUTPUT" -eq 1 ]; then
    sort -t' ' -k5 -hr /tmp/diskspace_input.tmp > /tmp/diskspace_sorted.tmp
    mv /tmp/diskspace_sorted.tmp /tmp/diskspace_input.tmp
  fi

  while read -r fs size used avail usep mount; do
    [ -z "$fs" ] && continue
    analyze_line "$fs" "$size" "$used" "$avail" "$usep" "$mount"
  done < /tmp/diskspace_input.tmp

  rm -f /tmp/diskspace_input.tmp
}

main "$@"